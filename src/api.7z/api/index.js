// import {
//   baseUrl, //引入baseUrl 
// } from "./env";
import axios from 'axios';
axios.defaults.timeout = 10000; //设置请求时间
// axios.defaults.baseURL = baseUrl;//设置默认接口地址
const api = {
  url
};



// axios.interceptors.request.use(function (config) {
//   // console.log(config)          
//   let tokenKey = cookies.get('jwt');
//   // if (tokenKey) {
//   //     config.headers['Authorization'] = tokenKey;
//   // }
//   if (config.url.search('upload') != -1) {
//     config.headers['Content-Type'] = "application/json" + 'multipart/form-data';
//   }
//   return config;

// }, function (error) {
//   // Do something with request error
//   return Promise.reject(error);
// });


