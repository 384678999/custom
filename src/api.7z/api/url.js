import { get, post } from './encapsulation'
import qs from 'qs'
export default {
  one: (params) => get('https://www.easy-mock.com/mock/5db6b44809633f24be4ca177/custom/one', params),
}